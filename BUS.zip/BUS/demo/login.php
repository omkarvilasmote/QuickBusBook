<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <center>
    <h2>Login</h2>
    <table border="1" cellpadding="7" cellspacing="0">
    <form action="act_login.php" method="post">
        <tr>
            <td>
                User Name :

            </td>
            <td>
            <input type="text" name="un" required/>
                </td>
            </tr>
            <tr>
                <td>
                Password :
                </td>
                <td>
                    <input type="password" name="pwd" required/>

                </td>
            </tr>
            <tr>
                <td colspan="2" align="center" bgcolor="skyblue">
                    <input type="submit" value="Submit">
                </td>
            </tr>
        
    </form>
    </table>
    <p><a href="register.php">New User</a></p>
    </center>
</body>
</html>