<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <center>
    <h2>New User</h2>
    <table border="1" cellpadding="7" cellspacing="0">
    <form action="act_register.php" method="post">
        <tr>
            <td>
                User Name :

            </td>
            <td>
            <input type="text" name="un" required/>
                </td>
            </tr>
            <tr>
                <td>
                New Password :
                </td>
                <td>
                    <input type="password" name="npwd" required/>

                </td>
            </tr>
            <tr>
                <td>
                Confirm Password :
                </td>
                <td>
                    <input type="password" name="cpwd" required/>

                </td>
            </tr>
            <tr>
                <td colspan="2" align="center" bgcolor="pink">
                    <input type="submit" value="Register">
                </td>
            </tr>
        
    </form>
    </table>
    <p><a href="login.php">Cancel</a></p>
    </center>
</body>
</html>