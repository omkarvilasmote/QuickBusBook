<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Welcome</title>
</head>
<body>
    <h2>Welcome</h2>
    <?php
    echo "<h3> Seconds ". date("s")."</h3>";
    $s = date('s');
    if($s%2==0){
        echo "Even";
    }else{
        echo "Odd";
    }
    echo "$s<a href='index.php'>Refresh</a>";
    
    ?>
</body>
</html>