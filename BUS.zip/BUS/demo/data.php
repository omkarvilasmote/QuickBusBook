<center>
    <h2>User List</h2>
    <table border="1" cellpadding="6" cellspacing="0">
        <tr bgcolor="khaki">
            <th>
                Sr No.
            </th>
            <th>
                User
            </th>
            <th>
                Role
            </th>
            <th>
                Action
            </th>
        </tr>
<?php
    $conn = mysqli_connect("localhost","root","","demo_db");
    if(!$conn){
        echo "Unable to connect!";
    }
    $query = "SELECT * FROM login WHERE role='member'";
    $result = mysqli_query($conn, $query)OR Die("Query Error");
    $srno = 0;
    while($row=mysqli_fetch_array($result)){
        $srno++;
        $un = $row["uname"];
        echo "<tr> ";
        echo "<td align='center'>$srno</td>";
        echo "<td>".$row["uname"]." </td>";
        echo "<td>".$row["role"]." </td>";

        echo "<td><a href='del_user.php?un=$un'>Del</a></td>";
        echo "</tr> ";
    }

    mysqli_close($conn);
?>
    </table>
    <p><a href="register.php">New User</a></p>
    
</center>