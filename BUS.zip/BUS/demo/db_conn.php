<?php
$conn = mysqli_connect("localhost","root","","demo_db");
if(!$conn){
    exit("Unable to connect!");
}
?>