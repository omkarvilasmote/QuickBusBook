<?php
$un = $_POST["un"];
$npwd = $_POST["npwd"];
$cpwd = $_POST["cpwd"];
if($npwd!=$cpwd){
    exit("<h2 style='color:red'>Passwords Mismatch</h2>");
}
require_once "db_conn.php";
$query = "INSERT INTO login (uname,pwd,role) VALUES ('$un','$npwd','member')";
     mysqli_query($conn, $query)OR Die("Error".mysqli_error($conn));
     if(mysqli_affected_rows($conn)>0){
        echo "<h2> User $un Registered</h2>";
     }


    mysqli_close($conn);

?>