<?php


$un = $_GET["un"];

require_once "db_conn.php";
$query = "DELETE FROM login WHERE uname='$un'";
     mysqli_query($conn, $query)OR Die("Error".mysqli_error($conn));
     if(mysqli_affected_rows($conn)>0){
        echo "<h2> User $un Deleted</h2>";
    }else{

        echo "<h2> User $un Not Found</h2>";
    }


    mysqli_close($conn);

?>