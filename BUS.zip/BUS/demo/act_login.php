<?php
$un = $_POST["un"];
$pwd = $_POST["pwd"];
require_once "db_conn.php";
$query = "SELECT * FROM login WHERE uname = '$un' AND pwd = '$pwd'";
    $result = mysqli_query($conn, $query)OR Die("Query Error");

    if($row=mysqli_fetch_array($result)){
        echo "Welcome ". $row["role"]."<br/>";
    }else{
        echo "Access Denied";
    }

    mysqli_close($conn);

?>